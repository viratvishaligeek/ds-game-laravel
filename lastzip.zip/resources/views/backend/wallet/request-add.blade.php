@extends('backend.include.layout')

@section('page-header')
    <header class="page-header page-header-compact page-header-light border-bottom bg-white mb-4">
        <div class="container-fluid px-4">
            <div class="page-header-content">
                <div class="row align-items-center justify-content-between pt-3">
                    <div class="col-auto mb-3">
                        <h1 class="page-header-title">
                            <div class="page-header-icon">
                                <i data-feather="plus-circle"></i>
                            </div>
                            {{ $pageName ?? 'Add Money Requests' }}
                        </h1>
                    </div>
                    <div class="col-auto mb-3">
                        <a href="{{ route('admin.wallet.request-withdraw') }}" class="btn btn-sm btn-light text-danger">
                            <i class="me-1" data-feather="arrow-up-right"></i>
                            Withdrawal Requests
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </header>
@endsection

@section('content')
    <div class="card">
        <div class="card-header bg-white py-3">
            <div class="row align-items-center">
                <div class="col">
                    <h5 class="mb-1 fw-bold text-dark">
                        Add Money Requests
                    </h5>
                    <small class="text-muted">
                        Review and process user wallet top-up requests.
                    </small>
                </div>
                <div class="col-auto">
                    <span class="badge bg-primary-soft text-primary px-3 py-2">
                        {{ $requests->total() }} Total
                    </span>
                </div>
            </div>
        </div>
        <div class="card-body">
            {{-- Filters --}}
            <form method="GET" action="{{ route('admin.wallet.request-add') }}" class="row g-2 mb-4">
                <div class="col-md-2">
                    <select name="status" class="form-select">
                        <option value="">All Status</option>
                        <option value="pending" @selected(request('status') === 'pending')>
                            Pending
                        </option>
                        <option value="approved" @selected(request('status') === 'approved')>
                            Approved
                        </option>
                        <option value="rejected" @selected(request('status') === 'rejected')>
                            Rejected
                        </option>
                    </select>
                </div>
                <div class="col-md-3">
                    <button class="btn  btn-primary">
                        <i data-feather="filter" class="me-1"></i>
                        Filter
                    </button>
                    <a href="{{ route('admin.wallet.request-add') }}" class="btn  btn-light">
                        Reset
                    </a>
                </div>
            </form>
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>#</th>
                            <th>User</th>
                            <th>Amount</th>
                            <th>UTR ID</th>
                            <th>Mode</th>
                            <th>Proof</th>
                            <th>Status</th>
                            <th>Time</th>
                            <th class="text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse ($requests as $request)
                            <tr>
                                <td>
                                    {{ $loop->iteration }}
                                </td>
                                <td style="min-width: 150px">
                                    <div class="fw-bold">
                                        {{ $request->user->name ?? 'N/A' }}
                                    </div>
                                    <small class="text-muted">
                                        {{ $request->user->phone ?? 'N/A' }}
                                    </small>
                                </td>
                                <td>
                                    <span class="fw-bold text-success">
                                        +₹{{ number_format((float) $request->amount, 2) }}
                                    </span>
                                </td>
                                <td>
                                    @if ($request->utr)
                                        <span class="font-monospace">
                                            {{ $request->utr }}
                                        </span>
                                    @elseif($request->transaction_id)
                                        <span class="font-monospace">
                                            {{ $request->transaction_id }}
                                        </span>
                                    @else
                                        <span class="text-muted">N/A</span>
                                    @endif
                                </td>
                                <td>
                                    <span class="badge bg-primary-soft text-primary">
                                        {{ strtoupper($request->payment_method ?? 'UPI') }}
                                    </span>
                                </td>
                                <td>
                                    @if ($request->screenshot)
                                        <button type="button" class="btn btn-sm btn-light text-primary view-proof-btn"
                                            data-image="{{ \Illuminate\Support\Facades\Storage::disk('public')->url(preg_replace('#^(storage/|public/)#', '', ltrim((string) $request->screenshot, '/'))) }}"
                                            data-bs-toggle="modal" data-bs-target="#proofModal">
                                            <i data-feather="image" class="me-1"></i>
                                            View
                                        </button>
                                    @else
                                        <span class="text-muted small">
                                            No proof
                                        </span>
                                    @endif
                                </td>
                                <td>
                                    @if ($request->status === 'pending')
                                        <span class="badge bg-warning-soft text-warning">
                                            Pending
                                        </span>
                                    @elseif ($request->status === 'approved')
                                        <span class="badge bg-success-soft text-success">
                                            Approved
                                        </span>
                                    @elseif ($request->status === 'rejected')
                                        <span class="badge bg-danger-soft text-danger">
                                            Rejected
                                        </span>
                                    @else
                                        <span class="badge bg-secondary-soft text-secondary">
                                            {{ ucfirst($request->status) }}
                                        </span>
                                    @endif
                                </td>
                                <td>
                                    <div class="small">
                                        {{ $request->created_at?->format('d M Y') }}
                                    </div>
                                    <small class="text-muted">
                                        {{ $request->created_at?->format('h:i A') }}
                                    </small>
                                </td>
                                <td class="text-end">
                                    @if ($request->status === 'pending' || $request->status === 'processing')
                                        {{-- Approve --}}
                                        <form action="{{ route('admin.wallet.request.approve', $request->id) }}"
                                            method="POST" class="d-inline approve-form">
                                            @csrf
                                            <button type="button" class="btn btn-sm btn-success approve-btn"
                                                data-name="{{ $request->user->name ?? 'User' }}"
                                                data-amount="{{ number_format((float) $request->amount, 2) }}">
                                                <i data-feather="check" class="me-1"></i>
                                                Approve
                                            </button>
                                        </form>
                                        {{-- Reject --}}
                                        <button type="button" class="btn btn-sm btn-outline-danger reject-btn"
                                            data-id="{{ $request->id }}" data-action="{{ route('admin.wallet.request.reject', $request->id) }}" data-name="{{ $request->user->name ?? 'User' }}"
                                            data-bs-toggle="modal" data-bs-target="#rejectModal">
                                            <i data-feather="x" class="me-1"></i>
                                            Reject
                                        </button>
                                    @else
                                        <span class="text-muted small">
                                            Processed
                                        </span>
                                    @endif
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="9" class="text-center py-5">
                                    <div class="text-muted">
                                        <i data-feather="inbox" style="width:48px;height:48px;"></i>
                                        <h6 class="mt-3 mb-1">
                                            No Add Money Requests
                                        </h6>
                                        <small>
                                            No wallet top-up requests found.
                                        </small>
                                    </div>
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
            @if ($requests->hasPages())
                <div class="mt-4">
                    {{ $requests->withQueryString()->links() }}
                </div>
            @endif
        </div>
    </div>

    {{-- Proof Modal --}}
    <div class="modal fade" id="proofModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        Payment Screenshot
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body text-center bg-light">
                    <img id="proofImage" src="" alt="Payment Screenshot" class="img-fluid rounded shadow-sm"
                        style="max-height:75vh;">
                </div>
            </div>
        </div>
    </div>

    {{-- Reject Modal --}}
    <div class="modal fade" id="rejectModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <form id="rejectForm" method="POST">
                    @csrf
                    <div class="modal-header">
                        <h5 class="modal-title text-danger">
                            Reject Request
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <p class="text-muted">
                            Rejecting request for
                            <strong id="rejectUserName"></strong>.
                        </p>
                        <label class="form-label fw-bold">
                            Rejection Remark
                        </label>
                        <textarea name="admin_remark" class="form-control" rows="4" maxlength="1000" required
                            placeholder="Enter reason for rejection..."></textarea>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">
                            Cancel
                        </button>
                        <button type="submit" class="btn btn-danger">
                            <i data-feather="x" class="me-1"></i>
                            Reject Request
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection

@section('script')
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            feather.replace();
            /*
             * Payment proof
             */
            document.querySelectorAll('.view-proof-btn').forEach(button => {
                button.addEventListener('click', function() {
                    const image = document.getElementById('proofImage');
                    image.onerror = function() {
                        this.onerror = null;
                        this.src = 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="640" height="360"><rect width="100%" height="100%" fill="#f1f5f9"/><text x="50%" y="50%" text-anchor="middle" dominant-baseline="middle" fill="#64748b" font-family="Arial" font-size="22">Image unavailable</text></svg>');
                    };
                    image.src = this.dataset.image;
                });
            });
            /*
             * Approve
             */
            document.querySelectorAll('.approve-btn').forEach(button => {
                button.addEventListener('click', function() {
                    const form = this.closest('form');
                    const name = this.dataset.name;
                    const amount = this.dataset.amount;
                    Swal.fire({
                        title: 'Approve Wallet Top-up?',
                        html: `
                        <div class="text-center">
                            <p class="mb-1">
                                User:
                                <strong>${name}</strong>
                            </p>
                            <p>
                                Amount:
                                <strong class="text-success">
                                    ₹${amount}
                                </strong>
                            </p>
                            <small class="text-muted">
                                This amount will be credited to the user's wallet.
                            </small>
                        </div>
                    `,
                        icon: 'question',
                        showCancelButton: true,
                        confirmButtonColor: '#1cc88a',
                        cancelButtonColor: '#858796',
                        confirmButtonText: 'Yes, Approve',
                        cancelButtonText: 'Cancel'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            form.submit();
                        }
                    });
                });
            });
            /*
             * Reject
             */
            document.querySelectorAll('.reject-btn').forEach(button => {
                button.addEventListener('click', function() {
                    const id = this.dataset.id;
                    const name = this.dataset.name;
                    document.getElementById('rejectUserName').textContent = name;
                    document.getElementById('rejectForm').action =
                        button.dataset.action;
                });
            });
        });
    </script>
@endsection
