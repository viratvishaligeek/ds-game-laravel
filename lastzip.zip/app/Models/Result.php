<?php

namespace App\Models;

use App\Models\Concerns\BelongsToSite;
use App\Models\GameResult;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Result extends Model
{
    use BelongsToSite;
    protected $primaryKey = 'id';
    public $timestamps = true;
    protected $guarded = ['id'];
    public function game()
    {
        return $this->belongsTo(Game::class);
    }
}
