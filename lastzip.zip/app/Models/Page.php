<?php

namespace App\Models;

use App\Models\Concerns\BelongsToSite;
use App\Models\GameResult;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Page extends Model
{
    use BelongsToSite;
    use SoftDeletes;
    protected $primaryKey = 'id';
    public $timestamps = true;
    protected $guarded = ['id'];

    protected $casts = [
        'menu_visible' => 'boolean',
        'menu_order' => 'integer',
        'noindex' => 'boolean',
    ];

}
